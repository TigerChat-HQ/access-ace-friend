# TIGER AI Command Center update

## Included
- Reworked the Command Center into working Tasks, Audit, and Developer readiness views.
- Added a manual task form and refresh control.
- Added a server-side `create_task` action to the existing `tiger-dev-planner` Supabase Edge Function.
- Kept task status changes and feedback triage behind the existing admin authorization check.
- Removed the accidentally bundled `.env` file and an embedded duplicate ZIP from this delivery.

## Apply the update
1. Back up the current GitHub repository.
2. Upload/replace the project files from this ZIP in the repository root. Do not upload `.env`.
3. Deploy the updated Supabase Edge Function `tiger-dev-planner` using your project's normal Supabase deployment workflow.
4. Confirm migration `0002_tiger_dev_tasks_and_audit.sql` has already been applied. If not, apply it once through Supabase migrations.
5. Build and test the project in your CI/development environment, then deploy after review.

## Important capability boundary
This update fixes and expands task planning, task tracking, and audit UI. It does NOT yet provide autonomous repository code writes, a browser IDE, isolated code execution, automated repair, or production deployment. Those require a server-side GitHub App/integration, a secure sandbox runner, and approval-gated PR/deployment services. Do not add GitHub tokens to frontend environment variables or browser code.

## Security
The source archive contained a `.env` file. It was deliberately excluded from this ZIP. If it contained real credentials, rotate them in the relevant providers and configure replacements only in the hosting provider's secret manager.
