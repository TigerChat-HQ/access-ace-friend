import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Bot, Sparkles, Lock, RefreshCw, Plus, ClipboardList, History, Code2, AlertCircle, ShieldCheck } from "lucide-react";

type Task = {
  id: string; title: string; summary: string | null; category: string; priority: string;
  risk: string; status: string; plan: any; created_at: string;
};
type Audit = { id: string; actor: string; action: string; details: any; created_at: string };
const NEXT: Record<string, string[]> = {
  planned: ["approved", "rejected"], approved: ["in_progress", "rejected"],
  in_progress: ["done", "rejected"], done: [], rejected: ["planned"],
};

export const TigerCommandCenter = () => {
  const { toast } = useToast();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [audit, setAudit] = useState<Audit[]>([]);
  const [busy, setBusy] = useState(false);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState<string | null>(null);
  const [view, setView] = useState<"tasks" | "audit" | "developer">("tasks");
  const [showCreate, setShowCreate] = useState(false);
  const [title, setTitle] = useState("");
  const [summary, setSummary] = useState("");
  const [category, setCategory] = useState("feature");

  const load = useCallback(async () => {
    setLoading(true);
    const [{ data: t, error: te }, { data: a, error: ae }] = await Promise.all([
      supabase.from("dev_tasks").select("*").order("created_at", { ascending: false }).limit(50),
      supabase.from("dev_audit_log").select("*").order("created_at", { ascending: false }).limit(50),
    ]);
    if (te || ae) toast({ title: "Command Center could not load", description: te?.message || ae?.message || "Check admin access and database migrations.", variant: "destructive" });
    setTasks((t as Task[]) || []); setAudit((a as Audit[]) || []); setLoading(false);
  }, [toast]);
  useEffect(() => { void load(); }, [load]);

  const call = async (body: Record<string, unknown>) => {
    const { data, error } = await supabase.functions.invoke("tiger-dev-planner", { body });
    if (error) {
      let detail = error.message;
      try { const context = (error as any).context; if (context?.text) detail = await context.text(); } catch { /* retain message */ }
      throw new Error(detail);
    }
    if (data?.error) throw new Error(data.error);
    return data;
  };
  const triage = async () => {
    setBusy(true);
    try { const r = await call({ action: "triage" }); toast({ title: r.created ? `Tiger AI planned ${r.created} task(s)` : "No new feedback to plan" }); await load(); }
    catch (e: any) { toast({ title: "Planning failed", description: e.message, variant: "destructive" }); }
    finally { setBusy(false); }
  };
  const createTask = async () => {
    if (!title.trim()) return;
    setBusy(true);
    try { await call({ action: "create_task", title: title.trim(), summary: summary.trim(), category }); setTitle(""); setSummary(""); setShowCreate(false); toast({ title: "Development task created" }); await load(); }
    catch (e: any) { toast({ title: "Could not create task", description: e.message, variant: "destructive" }); }
    finally { setBusy(false); }
  };
  const setStatus = async (id: string, status: string) => {
    try { await call({ action: "set_status", id, status }); await load(); }
    catch (e: any) { toast({ title: "Update failed", description: e.message, variant: "destructive" }); }
  };
  const riskVariant = (r: string) => (r === "high" ? "destructive" : r === "medium" ? "secondary" : "outline") as any;

  return <section className="space-y-3 rounded-xl border border-border bg-card/50 p-3 sm:p-4">
    <div className="flex flex-wrap items-center justify-between gap-2">
      <h2 className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground"><Bot className="h-4 w-4 text-primary" /> Tiger AI Command Center</h2>
      <Button size="sm" variant="outline" onClick={() => void load()} disabled={loading}><RefreshCw className={`mr-1 h-3.5 w-3.5 ${loading ? "animate-spin" : ""}`} /> Refresh</Button>
    </div>
    <div className="grid grid-cols-3 gap-2">
      <Button size="sm" variant={view === "tasks" ? "default" : "outline"} onClick={() => setView("tasks")}><ClipboardList className="mr-1 h-3.5 w-3.5"/>Tasks ({tasks.length})</Button>
      <Button size="sm" variant={view === "audit" ? "default" : "outline"} onClick={() => setView("audit")}><History className="mr-1 h-3.5 w-3.5"/>Audit ({audit.length})</Button>
      <Button size="sm" variant={view === "developer" ? "default" : "outline"} onClick={() => setView("developer")}><Code2 className="mr-1 h-3.5 w-3.5"/>Developer</Button>
    </div>
    {view === "tasks" && <>
      <div className="flex flex-wrap gap-2">
        <Button size="sm" onClick={() => setShowCreate(v => !v)}><Plus className="mr-1 h-3.5 w-3.5"/>New task</Button>
        <Button size="sm" variant="secondary" onClick={triage} disabled={busy}><Sparkles className="mr-1 h-3.5 w-3.5"/>{busy ? "Working…" : "Plan from feedback"}</Button>
      </div>
      {showCreate && <div className="space-y-2 rounded-lg border border-border p-3">
        <Input value={title} onChange={e => setTitle(e.target.value)} placeholder="Task title" maxLength={200}/>
        <Textarea value={summary} onChange={e => setSummary(e.target.value)} placeholder="Describe the change or bug" rows={3}/>
        <select className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm" value={category} onChange={e => setCategory(e.target.value)}><option value="feature">Feature</option><option value="bug">Bug</option><option value="ux">User experience</option><option value="performance">Performance</option><option value="security">Security</option></select>
        <div className="flex gap-2"><Button size="sm" onClick={createTask} disabled={busy || !title.trim()}>Save task</Button><Button size="sm" variant="ghost" onClick={() => setShowCreate(false)}>Cancel</Button></div>
      </div>}
      {loading && <p className="text-sm text-muted-foreground">Loading development tasks…</p>}
      {!loading && tasks.length === 0 && <p className="text-sm text-muted-foreground">No tasks yet. Create a task or plan from user feedback.</p>}
      {tasks.map(t => <article key={t.id} className="space-y-2 rounded-lg border border-border/70 bg-background p-3">
        <button type="button" className="w-full text-left" aria-expanded={open === t.id} onClick={() => setOpen(open === t.id ? null : t.id)}>
          <p className="text-sm font-medium">{t.title}</p><div className="mt-1 flex flex-wrap gap-1"><Badge variant="outline">{t.category}</Badge><Badge variant="secondary">{t.priority}</Badge><Badge variant={riskVariant(t.risk)}>risk: {t.risk}</Badge><Badge>{t.status.replaceAll("_", " ")}</Badge></div>
        </button>
        {open === t.id && <div className="space-y-2 text-xs text-muted-foreground">{t.summary && <p>{t.summary}</p>}{t.plan?.steps?.length > 0 && <ol className="list-decimal space-y-0.5 pl-4">{t.plan.steps.map((s: string, i: number) => <li key={i}>{s}</li>)}</ol>}{t.plan?.tests?.length > 0 && <p><b className="text-foreground">Tests:</b> {t.plan.tests.join("; ")}</p>}{t.risk === "high" && <p className="text-destructive">High-risk task: review carefully before approval.</p>}</div>}
        <div className="flex flex-wrap gap-1">{(NEXT[t.status] || []).map(s => <Button key={s} size="sm" variant={s === "rejected" ? "outline" : "secondary"} onClick={() => void setStatus(t.id, s)}>{s.replaceAll("_", " ")}</Button>)}</div>
      </article>)}
    </>}
    {view === "audit" && <div className="space-y-2">{audit.length === 0 && <p className="text-sm text-muted-foreground">No audit events yet.</p>}{audit.map(a => <div key={a.id} className="border-b border-border/60 pb-2 text-xs text-muted-foreground"><p>{new Date(a.created_at).toLocaleString()} · {a.actor === "tiger_ai" ? "Tiger AI" : "Admin"}</p><p className="text-foreground">{a.action}{a.details?.title ? ` — ${a.details.title}` : ""}</p></div>)}</div>}
    {view === "developer" && <div className="space-y-3 rounded-lg border border-border p-3">
      <div className="flex items-center gap-2"><AlertCircle className="h-4 w-4 text-amber-500"/><p className="text-sm font-semibold">Developer workspace readiness</p></div>
      <p className="text-xs text-muted-foreground">The current repository includes a task planner, task database and audit log. It does not yet include a secure GitHub write integration, isolated code runner, or deployment pipeline. This panel will not pretend to edit or test repository files until those services are configured.</p>
      <div className="grid gap-2 text-xs sm:grid-cols-2"><div className="flex items-center gap-2 rounded-md bg-muted/50 p-2"><ShieldCheck className="h-4 w-4 text-primary"/>Admin-gated task planning</div><div className="flex items-center gap-2 rounded-md bg-muted/50 p-2"><ShieldCheck className="h-4 w-4 text-primary"/>Task status and audit trail</div><div className="flex items-center gap-2 rounded-md bg-muted/50 p-2"><Lock className="h-4 w-4"/>GitHub code editing — not configured</div><div className="flex items-center gap-2 rounded-md bg-muted/50 p-2"><Lock className="h-4 w-4"/>Sandbox tests/deployment — not configured</div></div>
      <p className="text-xs text-muted-foreground">Next engineering step: provision a server-side GitHub App with repository-scoped permissions, then add an isolated runner and approval-gated pull-request workflow. Never place GitHub tokens in browser code.</p>
    </div>}
  </section>;
};
