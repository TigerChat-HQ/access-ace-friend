export default {
  logoUrl: "https://access-ace-friend.lovable.app/pwa-icon-192.png",
};
