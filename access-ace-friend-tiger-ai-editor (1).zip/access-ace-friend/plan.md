# Tiger AI Autonomous Developer Editor

## Implementation approach

Extend the existing `/tiger-ai` experience with a guarded **Developer Editor** mode alongside the existing assistant chat. The editor is an admin-facing, browser-local workspace that lets Tiger AI inspect a curated project snapshot, propose a structured implementation plan, preview a patch, apply approved changes to the working draft, and run lightweight validation checks. The existing Tiger AI chat, image generation, video generation, and feedback flow remain intact.

The first version intentionally keeps execution safe: no arbitrary shell commands, deploys, credential access, account authorization, or production writes are performed from the browser. Risky changes are visibly marked and require an explicit approval action. Workspace drafts persist in local storage so an interrupted session can resume.

## Project structure

- `src/pages/TigerAI.tsx` — dual-mode assistant and developer editor UI.
- `src/index.css` — existing dark/neon visual system, extended only if needed.
- `supabase/functions/tiger-ai/index.ts` — existing AI gateway used for developer planning requests.
- `plan.md` / `TODO.md` — implementation record and acceptance outcomes.

## Design

- **Candidate styles:** terminal noir (0.06), cybernetic workbench (0.89), soft SaaS workspace (0.05).
- **Chosen movement:** cybernetic workbench: a focused, dark engineering cockpit with neon green action states and violet reasoning accents.
- **Core principles:** evidence before action; readable diffs; explicit approval for risk; fast keyboard-first interactions.
- **Color philosophy:** retain TigerChats’ black surface and electric green primary, using violet for AI reasoning and amber/red only for risk and validation states.
- **Layout paradigm:** a split-pane workbench—file rail, code surface, and agent activity rail—rather than a centered chat column.
- **Signature elements:** Tiger AI status pulse, file-change counters, and compact execution timeline.
- **Interaction philosophy:** Tiger AI proposes; the developer reviews and applies. Every autonomous step has a visible state.
- **Typography:** existing system sans for UI, monospace for code, status and diffs.
- **Brand essence:** Tiger AI is the always-on pair programmer inside TigerChats: fast, transparent, and approval-aware. Personality: decisive, protective, technical.
- **Brand voice:** direct and calm. Example lines: “I found the smallest safe change.” “Review the patch, then let Tiger run the checks.”
- **Wordmark / mark:** existing tiger avatar paired with a terminal prompt glyph in the editor header.

## Acceptance

- Tiger AI exposes Assistant and Developer Editor modes.
- Developer Editor shows a project file rail, editable code surface, task prompt, plan, patch preview, and activity/check status.
- Tiger AI can generate a developer plan from the selected file and task prompt through the existing AI edge function.
- A proposed patch can be reviewed before applying it to the local draft workspace.
- Risky tasks display an approval gate and cannot be applied through the normal quick action.
- Draft workspace and editor state persist in local storage.
- Existing chat, media generation, and feedback functionality continue to work.
- The app builds and lints successfully.
