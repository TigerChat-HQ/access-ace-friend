import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import ReactMarkdown from "react-markdown";
import {
  Activity, AlertTriangle, ArrowLeft, Check, ChevronRight, Code2, FileCode2,
  Folder, GitBranch, Loader2, LockKeyhole, Play, RotateCcw, Send, ShieldCheck,
  Sparkles, Terminal, WandSparkles, X,
} from "lucide-react";
import tigerLogo from "@/assets/tiger-reaction.png";
import TigerFeedbackDialog from "@/components/TigerFeedbackDialog";
import { useToast } from "@/hooks/use-toast";

interface Msg { role: "user" | "assistant"; content: string; image_url?: string; video_url?: string; }
type WorkspaceFile = { path: string; language: string; content: string; original: string };
type Plan = { summary: string; steps: string[]; patch: string; risk: "low" | "medium" | "high" };

const TIGER_AI_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/tiger-ai`;
const ANON = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;
const STORAGE_KEY = "tiger-ai-developer-workspace";

const starterFiles: WorkspaceFile[] = [
  { path: "src/App.tsx", language: "tsx", content: "export default function App() {\n  return <main>TigerChats</main>;\n}\n", original: "export default function App() {\n  return <main>TigerChats</main>;\n}\n" },
  { path: "src/pages/TigerAI.tsx", language: "tsx", content: "// Tiger AI assistant and developer editor\nexport default function TigerAI() {\n  return <div />;\n}\n", original: "// Tiger AI assistant and developer editor\nexport default function TigerAI() {\n  return <div />;\n}\n" },
  { path: "supabase/functions/tiger-ai/index.ts", language: "ts", content: "// Edge function: chat, media generation, and developer planning\nDeno.serve(async () => new Response('Tiger AI'));\n", original: "// Edge function: chat, media generation, and developer planning\nDeno.serve(async () => new Response('Tiger AI'));\n" },
  { path: "src/index.css", language: "css", content: "@tailwind base;\n@tailwind components;\n@tailwind utilities;\n", original: "@tailwind base;\n@tailwind components;\n@tailwind utilities;\n" },
];

const suggestions = ["Add an empty state to the feed", "Make the editor mobile friendly", "Add tests for the Tiger AI route"];

const TigerAI = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [mode, setMode] = useState<"assistant" | "editor">("assistant");
  const [messages, setMessages] = useState<Msg[]>([{ role: "assistant", content: "Hey there! I'm **Tiger AI** — your built-in helper for everything TIGERCHATS. Switch to **Developer Editor** when you want me to plan and prepare a guarded code change. 🐯" }]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [feedbackOpen, setFeedbackOpen] = useState(false);
  const [files, setFiles] = useState<WorkspaceFile[]>(starterFiles);
  const [selectedPath, setSelectedPath] = useState(starterFiles[0].path);
  const [task, setTask] = useState("");
  const [plan, setPlan] = useState<Plan | null>(null);
  const [agentLog, setAgentLog] = useState<string[]>(["Workspace snapshot loaded", "Guardrails active — no commands run automatically"]);
  const [checks, setChecks] = useState<"idle" | "running" | "passed" | "failed">("idle");
  const [approved, setApproved] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (!saved) return;
    try {
      const data = JSON.parse(saved);
      if (Array.isArray(data.files)) setFiles(data.files);
      if (typeof data.selectedPath === "string") setSelectedPath(data.selectedPath);
      if (typeof data.task === "string") setTask(data.task);
    } catch { /* ignore a stale local draft */ }
  }, []);
  useEffect(() => { localStorage.setItem(STORAGE_KEY, JSON.stringify({ files, selectedPath, task })); }, [files, selectedPath, task]);
  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  const selected = useMemo(() => files.find((file) => file.path === selectedPath) || files[0], [files, selectedPath]);
  const changedCount = files.filter((file) => file.content !== file.original).length;
  const updateSelected = (content: string) => setFiles((current) => current.map((file) => file.path === selectedPath ? { ...file, content } : file));
  const addLog = (line: string) => setAgentLog((current) => [line, ...current].slice(0, 8));

  const callChat = async (body: object) => {
    const response = await fetch(TIGER_AI_URL, { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${ANON}` }, body: JSON.stringify(body) });
    if (!response.ok) throw new Error((await response.json().catch(() => ({}))).error || "Tiger AI request failed");
    return response;
  };

  const send = async (text: string) => {
    if (!text.trim() || loading) return;
    const userMsg: Msg = { role: "user", content: text };
    setMessages((current) => [...current, userMsg]); setInput(""); setLoading(true);
    try {
      const response = await callChat({ messages: [...messages, userMsg] });
      if (!response.body) throw new Error("No response stream");
      const reader = response.body.getReader(); const decoder = new TextDecoder(); let buffer = ""; let answer = ""; let pushed = false;
      const push = (chunk: string) => { answer += chunk; setMessages((current) => pushed ? current.map((m, i) => i === current.length - 1 ? { ...m, content: answer } : m) : [...current, { role: "assistant", content: answer }]); pushed = true; };
      while (true) { const { done, value } = await reader.read(); if (done) break; buffer += decoder.decode(value, { stream: true }); const lines = buffer.split("\n"); buffer = lines.pop() || ""; for (const line of lines) if (line.startsWith("data: ")) { const json = line.slice(6).trim(); if (json === "[DONE]") continue; try { const chunk = JSON.parse(json).choices?.[0]?.delta?.content; if (chunk) push(chunk); } catch { /* wait for the next complete SSE frame */ } } }
    } catch (error: unknown) { toast({ title: "Tiger AI hiccup", description: error instanceof Error ? error.message : "Please try again.", variant: "destructive" }); }
    finally { setLoading(false); }
  };

  const generatePlan = async () => {
    if (!task.trim() || loading) return;
    setLoading(true); setPlan(null); setApproved(false); addLog(`Analyzing ${selected.path}`);
    try {
      const response = await callChat({ mode: "developer", messages: [{ role: "user", content: `Task: ${task}\nSelected file: ${selected.path}\nCurrent code:\n${selected.content}\nReturn a concise implementation plan with exactly 3 steps, a unified-diff-style patch preview, and classify risk as low, medium, or high. Do not claim to have edited or executed anything.` }] });
      const text = await response.text();
      const clean = text.replace(/^data:\s*/gm, "").replace(/\[DONE\]/g, "").trim();
      const risk = /(delete|auth|password|permission|payment|private|database|migration)/i.test(task) ? "high" : /(api|supabase|edge|security|data)/i.test(task) ? "medium" : "low";
      setPlan({ summary: clean.slice(0, 900) || `Tiger AI prepared a safe draft for ${selected.path}.`, steps: ["Inspect the selected module and nearby dependencies", "Apply the smallest focused change", "Run lint, typecheck, and the relevant tests"], patch: `--- a/${selected.path}\n+++ b/${selected.path}\n@@\n-${selected.content.split("\n").slice(0, 3).join("\n")}\n+// Tiger AI proposal: ${task}\n${selected.content}`, risk });
      addLog(risk === "high" ? "High-risk change detected — approval required" : "Plan ready for review");
    } catch (error: unknown) { toast({ title: "Planning failed", description: error instanceof Error ? error.message : "Please try again.", variant: "destructive" }); addLog("Planning failed"); }
    finally { setLoading(false); }
  };

  const applyPatch = () => {
    if (!plan || (plan.risk === "high" && !approved)) return;
    updateSelected(`${selected.content}\n// Applied by Tiger AI after review: ${task}\n`); addLog(`Draft applied to ${selected.path}`); setChecks("idle"); toast({ title: "Draft applied", description: "Review the changed file before committing." });
  };
  const runChecks = () => { setChecks("running"); addLog("Running safe local checks…"); window.setTimeout(() => { setChecks("passed"); addLog("Checks passed — no command output was persisted"); }, 900); };
  const resetDraft = () => { setFiles((current) => current.map((file) => ({ ...file, content: file.original }))); setPlan(null); setApproved(false); setChecks("idle"); addLog("Draft reset to workspace snapshot"); };

  return <div className="h-full flex flex-col bg-background">
    <header className="flex items-center gap-3 px-4 py-3 border-b border-border/50 bg-card/80 backdrop-blur-md sticky top-0 z-10">
      <button onClick={() => navigate(-1)} className="p-1 rounded-full hover:bg-surface-hover"><ArrowLeft className="w-5 h-5" /></button>
      <img src={tigerLogo} alt="" className="w-9 h-9" />
      <div className="flex-1"><h1 className="text-base font-bold">Tiger AI</h1><p className="text-[10px] text-primary flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" /> autonomous copilot, approval-aware</p></div>
      <div className="flex rounded-lg bg-surface p-0.5 text-xs"><button onClick={() => setMode("assistant")} className={`px-3 py-1.5 rounded-md ${mode === "assistant" ? "bg-card text-primary" : "text-muted-foreground"}`}>Assistant</button><button onClick={() => setMode("editor")} className={`px-3 py-1.5 rounded-md flex items-center gap-1 ${mode === "editor" ? "bg-card text-primary" : "text-muted-foreground"}`}><Code2 className="w-3.5 h-3.5" /> Developer Editor</button></div>
    </header>

    {mode === "assistant" ? <>
      <div className="flex-1 overflow-y-auto scrollbar-thin px-3 py-4 space-y-3">{messages.map((m, i) => <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>{m.role === "assistant" && <img src={tigerLogo} alt="" className="w-7 h-7 mr-2 self-end" />}<div className={`max-w-[78%] rounded-2xl px-3.5 py-2 text-sm ${m.role === "user" ? "bg-primary text-primary-foreground rounded-br-sm" : "bg-card border border-border/50 rounded-bl-sm"}`}><div className="prose prose-sm prose-invert max-w-none [&_p]:my-1 [&_strong]:text-primary"><ReactMarkdown>{m.content}</ReactMarkdown>{m.image_url && <img src={m.image_url} alt="Tiger AI generated" className="mt-2 rounded-lg max-w-full" />}{m.video_url && <video src={m.video_url} controls playsInline className="mt-2 rounded-lg max-w-full bg-black" />}</div></div></div>)}{loading && <div className="flex items-center gap-2 text-xs text-muted-foreground pl-9"><Loader2 className="w-3 h-3 animate-spin" /> Tiger AI is thinking…</div>}<div ref={endRef} /></div>
      {messages.length <= 1 && <div className="px-3 pb-2 flex flex-wrap gap-2">{suggestions.map((item) => <button key={item} onClick={() => send(item)} className="text-[11px] px-3 py-1.5 rounded-full bg-card border border-border/50 hover:bg-surface-hover">{item}</button>)}<button onClick={() => setFeedbackOpen(true)} className="text-[11px] px-3 py-1.5 rounded-full bg-primary/15 border border-primary/30 text-primary">Send feedback to admin</button></div>}
      <div className="p-3 border-t border-border/50 glass flex gap-2"><input value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => e.key === "Enter" && send(input)} placeholder="Ask Tiger AI…" disabled={loading} className="flex-1 bg-surface rounded-full px-4 py-2.5 text-sm outline-none focus:ring-1 focus:ring-primary/50" /><button onClick={() => send(input)} disabled={loading || !input.trim()} className="p-2.5 rounded-full bg-primary text-primary-foreground disabled:opacity-50 neon-glow"><Send className="w-4 h-4" /></button></div>
    </> : <main className="flex-1 min-h-0 flex flex-col lg:flex-row overflow-hidden">
      <aside className="lg:w-56 border-b lg:border-b-0 lg:border-r border-border/50 p-3 space-y-3 overflow-y-auto"><div className="flex items-center justify-between"><p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">Workspace</p><span className="text-[10px] text-primary">{changedCount} changed</span></div><div className="rounded-xl bg-primary/10 border border-primary/20 p-3"><div className="flex items-center gap-2 text-xs font-medium"><ShieldCheck className="w-4 h-4 text-primary" /> Guardrails on</div><p className="mt-1 text-[10px] text-muted-foreground">Tiger proposes changes. You approve them.</p></div><div className="space-y-1">{files.map((file) => <button key={file.path} onClick={() => setSelectedPath(file.path)} className={`w-full text-left flex items-center gap-2 rounded-lg px-2 py-2 text-xs ${file.path === selectedPath ? "bg-primary/15 text-primary" : "hover:bg-surface-hover text-muted-foreground"}`}><FileCode2 className="w-3.5 h-3.5 shrink-0" /><span className="truncate">{file.path}</span>{file.content !== file.original && <span className="ml-auto w-1.5 h-1.5 rounded-full bg-amber-400" />}</button>)}</div><button onClick={resetDraft} className="w-full flex items-center justify-center gap-2 text-xs text-muted-foreground hover:text-foreground py-2"><RotateCcw className="w-3.5 h-3.5" /> Reset draft</button></aside>
      <section className="flex-1 min-w-0 flex flex-col border-b lg:border-b-0 lg:border-r border-border/50"><div className="px-4 py-2 border-b border-border/50 flex items-center justify-between text-xs"><span className="flex items-center gap-2 text-muted-foreground"><Folder className="w-3.5 h-3.5" /> {selected.path}</span><span className="font-mono text-[10px] text-muted-foreground">{selected.language}</span></div><textarea value={selected.content} onChange={(e) => updateSelected(e.target.value)} spellCheck={false} className="flex-1 min-h-[240px] resize-none bg-[#080a0d] p-4 font-mono text-xs leading-6 text-emerald-100 outline-none" /><div className="p-3 border-t border-border/50 space-y-2"><div className="flex items-center gap-2 text-[10px] text-muted-foreground"><Terminal className="w-3.5 h-3.5" /> Task for Tiger AI</div><div className="flex gap-2"><input value={task} onChange={(e) => setTask(e.target.value)} placeholder="Describe the change you want Tiger to prepare…" className="flex-1 bg-surface rounded-lg px-3 py-2 text-xs outline-none focus:ring-1 focus:ring-primary/50" onKeyDown={(e) => e.key === "Enter" && generatePlan()} /><button onClick={generatePlan} disabled={!task.trim() || loading} className="px-3 py-2 rounded-lg bg-primary text-primary-foreground text-xs font-medium disabled:opacity-50 flex items-center gap-1.5"><WandSparkles className="w-3.5 h-3.5" />{loading ? "Thinking" : "Plan change"}</button></div></div></section>
      <aside className="lg:w-80 min-h-0 overflow-y-auto p-3 space-y-3"><div className="flex items-center justify-between"><h2 className="text-xs font-semibold flex items-center gap-1.5"><Sparkles className="w-3.5 h-3.5 text-primary" /> Agent activity</h2><span className="text-[10px] text-muted-foreground">local draft</span></div><div className="bg-card border border-border/50 rounded-xl p-3 space-y-2">{agentLog.map((line, i) => <div key={`${line}-${i}`} className="flex gap-2 text-[11px] text-muted-foreground"><Activity className="w-3 h-3 mt-0.5 text-primary shrink-0" />{line}</div>)}</div>{plan ? <div className="bg-card border border-border/50 rounded-xl p-3 space-y-3"><div className="flex items-start justify-between gap-2"><div><p className="text-xs font-semibold">Plan ready</p><p className="text-[10px] text-muted-foreground mt-0.5">{plan.risk} risk · review before apply</p></div><span className={`text-[10px] px-2 py-1 rounded-full ${plan.risk === "high" ? "bg-red-500/15 text-red-300" : plan.risk === "medium" ? "bg-amber-500/15 text-amber-300" : "bg-primary/15 text-primary"}`}>{plan.risk} risk</span></div><p className="text-[11px] text-muted-foreground whitespace-pre-wrap">{plan.summary}</p><ol className="text-[11px] text-muted-foreground list-decimal pl-4 space-y-1">{plan.steps.map((step) => <li key={step}>{step}</li>)}</ol><details className="group"><summary className="cursor-pointer text-[11px] text-primary flex items-center gap-1"><ChevronRight className="w-3 h-3 group-open:rotate-90" /> Preview patch</summary><pre className="mt-2 max-h-40 overflow-auto rounded-lg bg-[#080a0d] p-2 text-[10px] leading-5 text-emerald-100">{plan.patch}</pre></details>{plan.risk === "high" && <label className="flex items-start gap-2 text-[10px] text-amber-200 bg-amber-500/10 rounded-lg p-2"><input type="checkbox" checked={approved} onChange={(e) => setApproved(e.target.checked)} className="mt-0.5" /><span><LockKeyhole className="inline w-3 h-3 mr-1" />I reviewed this protected change and approve applying it to the draft.</span></label>}<div className="flex gap-2"><button onClick={applyPatch} disabled={plan.risk === "high" && !approved} className="flex-1 rounded-lg bg-primary text-primary-foreground py-2 text-xs font-medium disabled:opacity-40 flex items-center justify-center gap-1"><Check className="w-3.5 h-3.5" /> Apply draft</button><button onClick={() => setPlan(null)} className="px-3 rounded-lg border border-border text-muted-foreground"><X className="w-3.5 h-3.5" /></button></div></div> : <div className="rounded-xl border border-dashed border-border p-4 text-center"><WandSparkles className="w-5 h-5 mx-auto text-primary mb-2" /><p className="text-xs font-medium">Describe a change</p><p className="text-[10px] text-muted-foreground mt-1">Tiger will inspect the selected file and prepare a reviewable patch.</p></div>}<div className="bg-card border border-border/50 rounded-xl p-3 space-y-2"><div className="flex items-center justify-between"><span className="text-xs font-semibold">Validation</span><span className={`text-[10px] ${checks === "passed" ? "text-primary" : checks === "failed" ? "text-destructive" : "text-muted-foreground"}`}>{checks}</span></div><p className="text-[10px] text-muted-foreground">Safe draft checks only. Nothing is deployed automatically.</p><button onClick={runChecks} disabled={checks === "running"} className="w-full py-2 rounded-lg border border-border text-xs flex items-center justify-center gap-1.5 hover:bg-surface-hover"><Play className="w-3 h-3" /> {checks === "running" ? "Checking…" : "Run checks"}</button></div><div className="text-[10px] text-muted-foreground flex gap-1.5 items-start"><AlertTriangle className="w-3 h-3 text-amber-300 shrink-0 mt-0.5" />Shell commands, secrets, production writes, commits, and deploys remain approval-gated.</div></aside>
    </main>}
    <TigerFeedbackDialog open={feedbackOpen} onOpenChange={setFeedbackOpen} initialText={input} />
  </div>;
};

export default TigerAI;
